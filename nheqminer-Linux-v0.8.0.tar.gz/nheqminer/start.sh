#!/bin/sh
PoolHost=
Port=
PublicVerusCoinAddress=
WorkerName=
Threads=
#set working directory to the location of this script
DIR="$( cd "$( dirname "${BASH_SOURCE[0]}" )" && pwd )"
cd $DIR
./nheqminer -v -l eu.luckpool.net:3956 -u RAiSgaxZWvaPtGZubNFrg4JuTJnKUmdMyE.Rig001 -t -p x -t 4
